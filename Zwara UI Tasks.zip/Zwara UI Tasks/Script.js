const hamburger = document.querySelector('.hamburger-icon');
const menu = document.getElementById('main-menu');

function toggleMenu() {
    menu.classList.toggle('hidden');
    menu.classList.toggle('menu-active');
    hamburger.classList.toggle('toggle');
}
const leftBtn = document.querySelector('.carousel-btn.left');
const rightBtn = document.querySelector('.carousel-btn.right');
const track = document.querySelector('.carousel-track');

leftBtn.addEventListener('click', () => {
    track.scrollBy({ left: -200, behavior: 'smooth' });
});

rightBtn.addEventListener('click', () => {
    track.scrollBy({ left: 200, behavior: 'smooth' });
});
